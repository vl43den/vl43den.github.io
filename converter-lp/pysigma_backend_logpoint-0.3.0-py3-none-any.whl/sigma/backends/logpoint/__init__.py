from .logpoint import Logpoint

backends = {"logpoint": Logpoint}
